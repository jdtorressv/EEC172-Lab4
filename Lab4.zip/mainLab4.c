//********************************************************************************
// Authors              - Shivam Desai, Joseph Torres
// Application Name     - Lab 4
// Application Overview - this lab permits the detection of dual tone multiple
//                        frequency (DTMF) waveforms via a microphone; in turn,
//                        the output is passed into an analog-to-digital converter,
//                        passed to the Launchpad by SPI, and decoded there using
//                        the Goertzel algorithm. By further interfacing the
//                        Launchpad with an OLED over SPI, we examine how such
//                        decodings can permit multi-tap text entry transcription
//                        and communication over UART.
//
//********************************************************************************
//
//
//
// Standard includes
#include <stdio.h>
#include <string.h>
// Driverlib includes
#include "hw_types.h"
#include "hw_ints.h"
#include "hw_memmap.h"
#include "hw_common_reg.h"
#include "interrupt.h"
#include "hw_apps_rcm.h"
#include "prcm.h"
#include "rom.h"
#include "rom_map.h"
#include "prcm.h"
#include "gpio.h"
#include "utils.h"
#include "spi.h"

// Common interface includes
#include "uart_if.h"
#include "uart.h"
#include "timer_if.h"
#include "timer.h"
#include "Adafruit_GFX.h"
#include "Adafruit_SSD1351.h"
#include "glcdfont.h"
#include "gpio_if.h"

#include "pin_mux_config.h"

#define SPI_IF_BIT_RATE  100000
#define BLACK 0x0000
#define WHITE 0xFFFF
#define BOARD UARTA1_BASE
#define BOARD_BASE PRCM_UARTA1
#define BUFF_SIZE 410
//*****************************************************************************
//                 GLOBAL VARIABLES -- Start
//*****************************************************************************
extern void(*const g_pfnVectors[])(void);

volatile unsigned long SW2_intcount;
volatile unsigned long SW3_intcount;
volatile unsigned char SW2_intflag;
volatile unsigned char SW3_intflag;
volatile int numSamples;
int buffer[BUFF_SIZE];
// To hold the powers of the candidate frequencies of a tone
int power_all[8];
// Original DTMF Frequencies
int f_tone[8] = { 697, 770, 852, 941, 1209, 1336, 1477, 1633 };
// 2*cos(2*PI*f/16kHz) << 14
int coeff[8] = { 31548, 31281, 30951, 30556, 29144, 28361, 27409, 26258 };
int decode;
int new_dig;
volatile long timeElapsed;
volatile long prevTime;
int global_x, global_y;

char outBuffer[20];
char inBuffer[20];
unsigned int inBufIdx;
int numPresses;
char prevButton;
int timerInts;
// Character Arrays used to index characters in transription
char twoB[3] = "ABC";
char threeB[3] = "DEF";
char fourB[3] = "GHI";
char fiveB[3] = "JKL";
char sixB[3] = "MNO";
char sevenB[4] = "PQRS";
char eightB[4] = "TUV";
char nineB[4] = "WXYZ";


//*****************************************************************************
//                 GLOBAL VARIABLES -- End
//*****************************************************************************


//*****************************************************************************
//                      LOCAL FUNCTION PROTOTYPES                           
//*****************************************************************************
static void BoardInit(void);
void initADC(void);
void LEDinit(void);

//*****************************************************************************
//                      LOCAL FUNCTION DEFINITIONS                         
//*****************************************************************************

// Entirely empties the message buffer
void clearBuffer() {
	int i;

	for (i = 0; i < 20; i++) {
		inBuffer[i] = ' ';
	}
}
// Message passing
void Messaget(char *str) {
	printf("message: %s\n", str);
	if (str != NULL) {
		while (*str != '\0') {
			MAP_UARTCharPut(BOARD, *(str++));
			MAP_UtilsDelay(8000);
		}
	}
}
// Draw characters in buffer to incoming screen
void printInBuffer() {

	int x = 0, y = 60, i = 0;


	while (i < strlen(inBuffer)) {

		if (inBuffer[i] == ' ') break;

		drawChar(x, y, inBuffer[i], BLACK, WHITE, 1);

		x += 6;
		i++;

		if (i % 20 == 0) {
			x = 0;
			y += 10;
		}
	}

}
// Clear Incoming Screen
void clearInScreen() {

	fillRect(0, 60, 120, 30, WHITE);
}
// Clear Outgoing Screen
void clearScreen() {

	fillRect(0, 0, 120, 30, WHITE);
}
// Print characters in buffer to outgoing screen
void printBuffer() {

	int x = 0, y = 0, i = 0;

	while (i < strlen(outBuffer)) {
		drawChar(x, y, outBuffer[i], BLACK, WHITE, 1);

		x += 6;
		i++;

		if (i % 20 == 0) {
			x = 0;
			y += 10;
		}
	}

}
// Prints the present character to the OLED based on the number of times a certain button has been pressed
void printCurChar() {

	char letter = 'x';

	MAP_UtilsDelay(800000);

	if (prevButton == '2') {
		letter = twoB[numPresses];
	}
	else if (prevButton == '3') {
		letter = threeB[numPresses];
	}
	else if (prevButton == '4') {
		letter = fourB[numPresses];
	}
	else if (prevButton == '5') {
		letter = fiveB[numPresses];
	}
	else if (prevButton == '6') {
		letter = sixB[numPresses];
	}
	else if (prevButton == '7') {
		letter = sevenB[numPresses];
	}
	else if (prevButton == '8') {
		letter = eightB[numPresses];
	}
	else if (prevButton == '9') {
		letter = nineB[numPresses];
	}

	if (letter != 'x') drawChar(global_x, global_y, letter, BLACK, WHITE, 1);

	return;
}
// return matching char
int find(char* first, char c) {

	int i;
	for (i = 0; i < strlen(first); i++) {
		if (c == first[i]) return 1;
	}

	return 0;
}

// Given button pressed, decide which character to add to or delete from buffer, or send buffer as message
void findText() {

	//printf("%d\n", numPresses);

	char idx3[6] = "234568";
	char idx4[2] = "79";
	char letter[1] = "%";
	if (find(idx3, prevButton)) {
		if (numPresses > 2) numPresses = 2;
	}

	if (find(idx4, prevButton)) {
		if (numPresses > 3) numPresses = 3;
	}

	if (prevButton == '2') {
		letter[0] = twoB[numPresses];
	}
	else if (prevButton == '3') {
		letter[0] = threeB[numPresses];
	}
	else if (prevButton == '4') {
		letter[0] = fourB[numPresses];
	}
	else if (prevButton == '5') {
		letter[0] = fiveB[numPresses];
	}
	else if (prevButton == '6') {
		letter[0] = sixB[numPresses];
	}
	else if (prevButton == '7') {
		letter[0] = sevenB[numPresses];
	}
	else if (prevButton == '8') {
		letter[0] = eightB[numPresses];
	}
	else if (prevButton == '9') {
		letter[0] = nineB[numPresses];
	}
	else if (prevButton == '*') {
		outBuffer[strlen(outBuffer) - 1] = '\0';
		clearScreen();
		printBuffer();
		global_x -= 6;
		return;
	}
	else if (prevButton == '#') {
		inBufIdx = 0;
		clearBuffer();
		clearInScreen();
		Messaget(outBuffer);
		clearScreen();
		outBuffer[0] = '\0';
		printBuffer();
		global_x = 0;
		global_y = 0;
		return;
	}
	else {
		return;

	}

	strcat(outBuffer, letter);

	global_x += 6;

	if (global_x > 120) {
		global_x = 0;
		global_y = 10;
	}

	printf("outbuffer: %s\n", outBuffer);
}


//*****************************************************************************
//
//! Board Initialization & Configuration
//!
//! \param  None
//!
//! \return None
//
//*****************************************************************************
static void
// Initialize Board
BoardInit(void) {
	MAP_IntVTableBaseSet((unsigned long)&g_pfnVectors[0]);

	// Enable Processor
	//
	MAP_IntMasterEnable();
	MAP_IntEnable(FAULT_SYSTICK);

	PRCMCC3200MCUInit();
}

// Triggered when timer for same button press runs out
void TimerIntHandler() {
	Timer_IF_InterruptClear(TIMERA1_BASE);
	Timer_IF_Stop(TIMERA1_BASE, TIMER_A);
	timerInts++;

	//printf("interrupt\n"); //call second decoder here
	findText();
	// reset prevButton
	prevButton = '?';

}
// Goertzel implemenation, see https://github.com/OmaymaS/DTMF-Detection-Goertzel-Algorithm-
long int goertzel(int sample[], long int coeff, int N) {
	//initialize variables to be used in the function

	int Q, Q_prev, Q_prev2, i;
	long prod1, prod2, prod3, power;
	Q_prev = 0;           //set delay element1 Q_prev as zero
	Q_prev2 = 0;          //set delay element2 Q_prev2 as zero
	power = 0;            //set power as zero

	for (i = 0; i < N; i++)   // loop N times and calculate Q, Q_prev, Q_prev2 at each iteration
	{
		Q = (sample[i]) + ((coeff * Q_prev) >> 14) - (Q_prev2);   // >>14 used as the coeff was used in Q15 format
		Q_prev2 = Q_prev;     // shuffle delay elements
		Q_prev = Q;
	}

	//calculate the three products used to calculate power
	prod1 = ((long)Q_prev * Q_prev);
	prod2 = ((long)Q_prev2 * Q_prev2);
	prod3 = ((long)Q_prev * coeff) >> 14;
	prod3 = (prod3 * Q_prev2);
	power = ((prod1 + prod2 - prod3)) >> 8;   //calculate power using the three products and scale the result down

	return power;
}

// Actual key stroke is decoded in post_test
char post_test(void) {

	//initialize variables to be used in the function
	int i, row, col, max_power;

	// array with the order of the digits in the DTMF system
	char row_col[4][4] =
	{
		{ '1', '2', '3', 'A' },
		{ '4', '5', '6', 'B' },
		{ '7', '8', '9', 'C' },
		{ '*', '0', '#', 'D' }
	};

	// find the maximum power in the row frequencies and the row number
	max_power = 0;                //initialize max_power=0

	for (i = 0; i < 4; i++)       //loop 4 times from 0>3 (the indecies of the rows)
	{
		if (power_all[i] > max_power) //if power of the current row frequency > max_power
		{
			max_power = power_all[i]; //set max_power as the current row frequency
			row = i;      //update row number
		}
	}

	//printf("row_power: %d\n", max_power);

	// find the maximum power in the column frequencies and the column number
	max_power = 0;        //initialize max_power=0

	for (i = 4; i < 8; i++)   //loop 4 times from 4>7 (the indecies of the columns)
	{
		if (power_all[i] > max_power) //if power of the current column frequency > max_power
		{
			max_power = power_all[i]; //set max_power as the current column frequency
			col = i;      //update column number
		}
	}

	/*
	if (power_all[col] == 0 && power_all[row] == 0)   //if the maximum powers equal zero > this means no signal or inter-digit pause
	new_dig = 1;        //set new_dig to 1 to display the next decoded digit
	*/





	//printf("col_power: %d\nbutton: %c\n\n\n", max_power, row_col[row][col - 4]);

	if ((power_all[col] > 150000 && power_all[row] > 150000))// && (new_dig == 1))   // check if maximum powers of row & column exceed certain threshold AND new_dig flag is set to 1
	{


		return row_col[row][col - 4];

	}
	else {
		return 'x';
	}

}



// For debugging
void debugPrintBuffer() {

	int i;

	for (i = 0; i < numSamples; i++) {
		printf("%d: %d\n", i, buffer[i]);
	}

}
// Data from ADC is read in big endian byte order, bits are shifted to read in appropriate byes, dc bias is removed
void readData() {

	unsigned short read1 = 0;
	unsigned short read2 = 0;

	GPIOPinWrite(GPIOA0_BASE, 0x40, 0x00);

	MAP_SPITransfer(GSPI_BASE, 0, &read1, 1, SPI_CS_ENABLE | SPI_CS_DISABLE);
	MAP_SPITransfer(GSPI_BASE, 0, &read2, 1, SPI_CS_ENABLE | SPI_CS_DISABLE);

	GPIOPinWrite(GPIOA0_BASE, 0x40, 0x40);

	unsigned short shifted_read = read1 << 8 | read2;

	shifted_read = shifted_read << 3;
	shifted_read = shifted_read >> 6;

	//printf("%d\n", shifted_read);
	buffer[numSamples] = (shifted_read - 387);
	numSamples++;


}
// Triggered to implement sampling rate until 410 block size is reached
void TimerA0IntHandler() {
	Timer_IF_InterruptClear(TIMERA0_BASE);

	if (numSamples < 410) {
		readData();
	}
	else if (numSamples == 410) {
		Timer_IF_Stop(TIMERA0_BASE, TIMER_A);
		decode = 1;
	}

}
// Initialize timers
void initTimer() {

	Timer_IF_Init(PRCM_TIMERA1, TIMERA1_BASE, TIMER_CFG_PERIODIC, TIMER_A, 0);
	Timer_IF_IntSetup(TIMERA1_BASE, TIMER_A, TimerIntHandler);


	Timer_IF_Init(PRCM_TIMERA0, TIMERA0_BASE, TIMER_CFG_PERIODIC, TIMER_A, 0);
	Timer_IF_IntSetup(TIMERA0_BASE, TIMER_A, TimerA0IntHandler);
	MAP_TimerLoadSet(TIMERA0_BASE, TIMER_A, 5000);
	MAP_TimerEnable(TIMERA0_BASE, TIMER_A);

}
// Set up Analog to Digital Converter
void initADC() {
	MAP_PRCMPeripheralClkEnable(PRCM_GSPI, PRCM_RUN_MODE_CLK);

	// Reset the peripheral
	MAP_PRCMPeripheralReset(PRCM_GSPI);

	MAP_SPIReset(GSPI_BASE);

	// Configure SPI interface
	MAP_SPIConfigSetExpClk(GSPI_BASE, MAP_PRCMPeripheralClockGet(PRCM_GSPI),
		400000, SPI_MODE_MASTER, SPI_SUB_MODE_0,
		(SPI_SW_CTRL_CS |
			SPI_4PIN_MODE |
			SPI_TURBO_OFF |
			SPI_CS_ACTIVEHIGH |
			SPI_WL_8));

	MAP_SPIEnable(GSPI_BASE);
}
// Trigger UART handler when message passing
static void UARTIntHandler() {

	unsigned long intStatus = MAP_UARTIntStatus(BOARD, 1);
	UARTIntClear(BOARD, UART_INT_RX | UART_INT_RT | UART_INT_TX);

	while (MAP_UARTCharsAvail(BOARD) && (intStatus & UART_INT_RX)) {
		unsigned char c = MAP_UARTCharGet(BOARD);
		inBuffer[inBufIdx] = c;
		inBufIdx++;
	}

	printf("in: %s\n", inBuffer);
	printInBuffer();

}

// Initialize UART
void UARTinit() {
	MAP_UARTConfigSetExpClk(BOARD, MAP_PRCMPeripheralClockGet(BOARD_BASE), UART_BAUD_RATE, (UART_CONFIG_WLEN_8 | UART_CONFIG_STOP_ONE | UART_CONFIG_PAR_NONE));
	MAP_UARTIntRegister(BOARD, UARTIntHandler);
	MAP_UARTFIFODisable(BOARD);
	MAP_UARTIntEnable(BOARD, UART_INT_RX | UART_INT_RT);

}
// Called upon completion of Goertzel algorithm. After post_test returns button, check if button is valid. If so, either
// start a timer, set presses to zero, and find corresponding button, for increment counter. Finally, print character.
void decodeFreq() {
	char button = post_test();

	if (button != 'x') {

		printf("%c\n", button);
		if (button == prevButton
			) {
			numPresses++;
		}
		else {
			Timer_IF_Stop(TIMERA1_BASE, TIMER_A);
			findText();
			numPresses = 0;

			Timer_IF_Start(TIMERA1_BASE, TIMER_A, 1750);
		}

		prevButton = button;
		printCurChar();
	}




	return;
}


// Main
int main() {
	BoardInit();

	PinMuxConfig();
	// reinitarray();

	global_x = 0;
	global_y = 0;
	//LEDinit();

	initADC();
	Adafruit_Init();
	fillScreen(BLACK);
	initTimer();
	UARTinit();


	inBufIdx = 0;
	numSamples = 0;
	prevButton = '?';

	while (1) {

		decode = 0;
		while (decode == 0);

		{
			Timer_IF_InterruptClear(TIMERA0_BASE);
			Timer_IF_Stop(TIMERA0_BASE, TIMER_A);

			int i;
			for (i = 0; i < 8; i++) {
				power_all[i] = goertzel(buffer, coeff[i], 410);
				//printf("%d\n", power_all[i]);
			}
			//call post_test function
			decodeFreq();



			MAP_UtilsDelay(80000);

			decode = 0;
			numSamples = 0;
			MAP_TimerLoadSet(TIMERA0_BASE, TIMER_A, 5000);
			MAP_TimerEnable(TIMERA0_BASE, TIMER_A);
		}

	}

}